@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@class genexus_sd_SdtCardInformation;

@protocol GXEOProtocol_GXEOCardIO <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) BOOL canReadCard NS_SWIFT_NAME(canReadCard);
@property(nonatomic, readwrite) BOOL collectCardholderName NS_SWIFT_NAME(collectCardholderName);
@property(nonatomic, readwrite) BOOL collectCVV NS_SWIFT_NAME(collectCVV);
@property(nonatomic, readwrite) BOOL collectExpiry NS_SWIFT_NAME(collectExpiry);
@property(nonatomic, readwrite) BOOL collectPostalCode NS_SWIFT_NAME(collectPostalCode);
@property(nonatomic, readwrite) NSInteger detectionMode NS_SWIFT_NAME(detectionMode);
@property(nonatomic, readwrite) BOOL disableManualEntry NS_SWIFT_NAME(disableManualEntry);
@property(nonatomic, readwrite) BOOL restricPostalCodeNumeric NS_SWIFT_NAME(restricPostalCodeNumeric);
@property(nonatomic, readwrite) BOOL scanExpiry NS_SWIFT_NAME(scanExpiry);
@property(nonatomic, readwrite) NSString * scanInstructionsText NS_SWIFT_NAME(scanInstructionsText);
@property(nonatomic, readwrite) BOOL suppressScanConfirmation NS_SWIFT_NAME(suppressScanConfirmation);

+ (genexus_sd_SdtCardInformation *)scanCard NS_SWIFT_NAME(scanCard());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOCardIO)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOCardIO> gxEOClass_GXEOCardIO;

@end

NS_ASSUME_NONNULL_END
