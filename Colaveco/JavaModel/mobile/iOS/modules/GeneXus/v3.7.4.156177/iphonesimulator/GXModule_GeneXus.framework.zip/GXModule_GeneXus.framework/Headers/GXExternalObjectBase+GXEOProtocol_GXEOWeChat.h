@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOWeChat <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) BOOL isAvailable NS_SWIFT_NAME(isAvailable);

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOWeChat)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOWeChat> gxEOClass_GXEOWeChat;

@end

NS_ASSUME_NONNULL_END
