//
//  GXGlobalImports.h
//  GXModule_GeneXusSecurity
//

#ifndef GXGlobalImports_h
#define GXGlobalImports_h

@import GXCoreBL;
@import GXDataLayer;
@import GXFoundation;
@import GXObjectsModel;
@import GXStandardClasses;
@import YAJL;

@import GXModule_GeneXus;

#endif /* GXGlobalImports_h */